
<?php
require('stripe-php-master/init.php');

$publishableKey=
"pk_test_51Hz4GEKEezb4E17nB77dHoopjCzlO77EOL7KWEth5ke7tSC0DSHwZTHdwYtlG4jQNR0IwmDysb7dHxoRJH0AIETs00qjKCaA48";

$secretKey=
"sk_test_51Hz4GEKEezb4E17nriTz1ejcBu7pMAHrIuYUkbd4Rlkmuk3rrouSz2ucPMiSx5FUgUn1wK3jGtZf4DtChRi8aXrF00BpQoTI4o";

\stripe\stripe::setApikey($secretKey);




?>